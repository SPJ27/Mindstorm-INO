#ifndef BLUETOOTH_H
#define BLUETOOTH_H

char bluetooth_read();

#endif
