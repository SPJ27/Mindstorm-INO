#ifndef MOTORS_H
#define MOTORS_H

#include <Arduino.h>
void move(uint8_t motor, uint8_t direction, uint8_t speed);

#endif
