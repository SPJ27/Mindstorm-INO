#ifndef INFRARED_H
#define INFRARED_H

#include <Arduino.h>

int check_infrared(uint8_t port);
#endif
