#ifndef DISTANCE_H
#define DISTANCE_H

#include <Arduino.h>

float find_distance(uint8_t port);

#endif
