#ifndef BUTTONS_H
#define BUTTONS_H

#include <Arduino.h>


int detect_action(int pin);

#endif