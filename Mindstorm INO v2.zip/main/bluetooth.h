#ifndef BLUETOOTH_H
#define BLUETOOTH_H

String bluetooth_read();

#endif
