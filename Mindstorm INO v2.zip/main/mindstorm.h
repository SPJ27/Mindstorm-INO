#ifndef MINDSTORM_H
#define MINDSTORM_H

extern const int M1;
extern const int M2;

extern const int A;
extern const int B;
extern const int C;

extern const int SA;
extern const int SB;

extern const int FRONT; 
extern const int BACK; 

void setup_modules();

#endif
